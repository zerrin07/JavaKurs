import java.util.ArrayList;
import java.sql.*;

public class ComplexCityAdress
{
	public Connection connect()
	{
		String url = "jdbc:postgresql:test";
		String user = "postgres";
		String password = "A123456a";
		
		Connection conn = null;
        	try
		{
			conn = DriverManager.getConnection(url, user, password);
			System.out.println("Connected to the PostgreSQL server successfully.");
		}
		catch (SQLException e)
		{
			System.out.println(e.getMessage());
		}
		return conn;
	}
	
	public static void main(String[] args)
	{
		ComplexCityAdress app = new ComplexCityAdress();
		ArrayList<City> ctyList= new ArrayList<City>();
		
		try
		{
			
			Connection conn = app.connect();
			Statement st = conn.createStatement();
			ResultSet rs = st.executeQuery("SELECT * FROM public.\"City\"");
			
			while (rs.next())
			{
				City ct = new City();
				ct.Id = rs.getInt("Id");
				ct.Name = rs.getString("Name");
				ctyList.add(ct);

				Statement stAd = conn.createStatement();
				ResultSet rsAd = stAd.executeQuery("SELECT * FROM public.\"Adress\"");
				
				while (rsAd.next())
				{
					Adress ad = new Adress();
					ad.Id = rsAd.getInt("Id");
					ad.CustomerId = rsAd.getInt("CustomerId");
					ad.CityId = rsAd.getInt("CityId");
					ad.Adress = rsAd.getString("Adress");
					ct.adList.add(ad);
				}
				rsAd.close();
				stAd.close();
			}
			rs.close();
			st.close();

			for(City b : ctyList)
			{
				System.out.println(b.Id + "\t" + b.Name);
				for(Adress c : b.adList)
				{
					System.out.println(c.Id + "\t" + c.CustomerId + "\t" + c.CityId + "\t" + c.Adress);
				}
			}
			
			
		}
		catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}
	}
}

class City
{
	public int Id;
	public String Name;
	ArrayList<Adress> adList= new ArrayList<Adress>();	
}
class Adress
{
	public int Id;
	public int CustomerId;
	public int CityId;
	public String Adress;
}
