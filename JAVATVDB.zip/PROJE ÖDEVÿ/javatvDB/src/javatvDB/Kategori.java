package javatvDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Kategori {
	public int Id;
	public String KategoriType;
	public Film film = new Film();
	public Dizi dizi = new Dizi();
	
	public ArrayList<Kategori> kategoriArray=new ArrayList<Kategori>();
	
	public void kayit(){ 
		String stmt = "insert into public.\"kategori\"(\"KategoriType\") Values(\'"+this.KategoriType+"\')";
		this.Id = DBOperation.Save(stmt);
		film.KategoriId = this.Id;
		film.kayit();
		dizi.KategoriId = this.Id;
		dizi.kayit();
	}
	public void listele() {
		String stmt = "Select * from public.\"kategori\"";
		ResultSet rs = DBOperation.returnRS(stmt);
		try {
			while(rs.next()) {
			Kategori kat= new Kategori();
			kat.Id=rs.getInt("Id");
			kat.KategoriType = rs.getString("KategoriType");
			kategoriArray.add(kat);
			}
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(Kategori c : kategoriArray)
		{
			System.out.println(c.Id+"\t"+c.KategoriType);
		}
	}
}
