package javatvDB;

public class Uyetipi {
	public int Id;
	public int UyeType;
}
