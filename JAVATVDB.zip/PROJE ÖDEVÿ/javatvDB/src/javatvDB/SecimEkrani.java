package javatvDB;
import java.util.Scanner;
public class SecimEkrani {
	
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		Yonetmen yon = new Yonetmen();
		Kategori kat = new Kategori();
		Dizi diz = new Dizi();
		Film flm = new Film();
		System.out.println("JavaTVDB ye hoşgeldiniz Lütfen Seçim yapiniz");
		System.out.print("(1) Yonetmen \n"
				+ "(2) Kategori \n"
				+ "(3) Dizi \n"
				+ "(4) Film \n");
		int secim = input.nextInt();
		
		if(secim == 1) {
			 yon.listele();
			 System.out.println("Tercih ettiğiniz yonetmen Id giriniz...");
			 int yonetmenValue = input.nextInt();
			 diz.listele(yonetmenValue);
			 flm.listele(yonetmenValue);
			 System.out.println("İyi seyil...");
		}
		else if(secim == 2) {
			kat.listele();
			System.out.println("Tercih ettiğiniz kategori Id giriniz...");
			int kategoriValue = input.nextInt();
			
		}
		else if(secim == 3) {
			diz.listele();
		}
		else if(secim == 4) {
			flm.listele();
		}

	}

}
