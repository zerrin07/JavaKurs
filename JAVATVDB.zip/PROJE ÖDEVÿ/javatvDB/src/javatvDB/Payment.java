package javatvDB;

public class Payment {
	public int Id;
	public String PayType;
}
