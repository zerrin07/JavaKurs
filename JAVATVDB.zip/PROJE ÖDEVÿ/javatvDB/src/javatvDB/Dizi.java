package javatvDB;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class Dizi {
	public int Id;
	public String Name;
	public double IMDB;
	public int Time;
	public String VisionDate; 
	public ArrayList<Dizi> diziArray=new ArrayList<Dizi>();
	/*-------------------------*/
	public int YonetmenId;
	public int KategoriId;	
	public int ReklamId;
	/*
	public ArrayList<Yonetmen> yonetmenArray=new ArrayList<Yonetmen>();
	public ArrayList<Kategori> kategoriArray=new ArrayList<Kategori>();
	public ArrayList<Reklam> reklamArray=new ArrayList<Reklam>();
	*/
	public void kayit() {
		String stmt = "Insert into public.\"dizi\"(\"Id\",\"Name\",\"IMDB\",\"Time\",\"VisionDate\",\"YonetmenId\",\"KategoriId\",\"ReklamId\") "
				+ "values("+this.YonetmenId+","+this.KategoriId+","+this.ReklamId+")";
		this.Id = DBOperation.Save(stmt);
	}
	public void listele() {
		String stmt = "Select * from public.\"dizi\"";
		ResultSet rs = DBOperation.returnRS(stmt);
		try {
			while(rs.next()) {
			Dizi diz= new Dizi();
			diz.Id=rs.getInt("Id");
			diz.Name=rs.getString("Name");
			diz.IMDB=rs.getInt("IMDB");
			diz.Time=rs.getInt("Time");
			diz.VisionDate=rs.getString("VisionDate");
			diz.YonetmenId=rs.getInt("YonetmenId");
			diz.KategoriId=rs.getInt("KategoriId");
			diz.ReklamId=rs.getInt("ReklamId");
			diziArray.add(diz);
			}
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(Dizi c : diziArray)
		{
			System.out.println(c.Id+"\t"+c.Name+"\t\t\t\t"+c.IMDB+"\t"+c.Time+"\t"+c.VisionDate+"\t"+c.YonetmenId+"\t"+c.KategoriId+"\t"+c.ReklamId);
		}
	}
	public void listele(int i,int j) {
		String stmt = "Select * from public.\"dizi\" where \"YonetmenId\" =" + i;
		ResultSet rs = DBOperation.returnRS(stmt);
		try {
			while(rs.next()) {
			Dizi diz= new Dizi();
			diz.Id=rs.getInt("Id");
			diz.Name=rs.getString("Name");
			diz.IMDB=rs.getInt("IMDB");
			diz.Time=rs.getInt("Time");
			diz.VisionDate=rs.getString("VisionDate");
			diz.YonetmenId=rs.getInt("YonetmenId");
			diz.KategoriId=rs.getInt("KategoriId");
			diz.ReklamId=rs.getInt("ReklamId");
			diziArray.add(diz);
			}
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(Dizi c : diziArray)
		{
			System.out.println(c.Id+"\t"+c.Name+"\t\t\t\t"+c.IMDB+"\t"+c.Time+"\t"+c.VisionDate+"\t"+c.YonetmenId+"\t"+c.KategoriId+"\t"+c.ReklamId);
		}
	}
	
}
