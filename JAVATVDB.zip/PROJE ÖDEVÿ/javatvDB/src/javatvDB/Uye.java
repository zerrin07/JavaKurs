package javatvDB;

public class Uye {
	public int Id;
	public String Name;
	public String Surname;
	public String Eposta;
	public String Sifre;
	/*bire bir ilişki için*/
	public Payment pay = new Payment();
	public Uyetipi uyetipi = new Uyetipi();
	
}
