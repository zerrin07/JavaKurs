insert into public."payment"("PaymentType")
Values('Kredi Kartı');
insert into public."payment"("PaymentType")
Values('Banka Kartı');
insert into public."payment"("PaymentType")
Values('Paypal');
insert into public."payment"("PaymentType")
Values('Kripto');
insert into public."payment"("PaymentType")
Values('Kupon');
insert into public."payment"("PaymentType")
Values('Papara');

select * from public."payment"

insert into public."uyetipi"("Uyetype")
Values('Basic');
insert into public."uyetipi"("Uyetype")
Values('Premium');

select * from public."uyetipi"

insert into public."kategori"("KategoriType")
Values('Aksiyon');
insert into public."kategori"("KategoriType")
Values('Korku');
insert into public."kategori"("KategoriType")
Values('Romantik');
insert into public."kategori"("KategoriType")
Values('Bilimkurgu');
insert into public."kategori"("KategoriType")
Values('Gerilim');
insert into public."kategori"("KategoriType")
Values('Fantastik');
insert into public."kategori"("KategoriType")
Values('Macera');
insert into public."kategori"("KategoriType")
Values('Sanat');
insert into public."kategori"("KategoriType")
Values('Drama');
insert into public."kategori"("KategoriType")
Values('Komedi');
insert into public."kategori"("KategoriType")
Values('Savas');
insert into public."kategori"("KategoriType")
Values('Kara Mizah');

select * from public."kategori"

insert into public."reklam"("ReklamType")
values('Var');
insert into public."reklam"("ReklamType")
values('Yok');

select * from public."reklam"

insert into public."uye"("Name","Surname","Eposta","Sifre","PaymentId","UyetipiId")
Values('Engin','Yıldız','engin@gmail.com','1234',6,2);
insert into public."uye"("Name","Surname","Eposta","Sifre","PaymentId","UyetipiId")
Values('Dilan','Yılmaz','dilan@gmail.com','1907',2,1);

select * from uye

insert into public."yonetmen"("Name","Surname","Birthday")
values('Peter Robert','Jackson','1.1.1966');
insert into public."yonetmen"("Name","Surname","Birthday")
Values('Francis Ford','Coppola','07.04.1939');
insert into public."yonetmen"("Name","Surname","Birthday")
Values('Frank','Darabant','28.01.1959');
insert into public."yonetmen"("Name","Surname","Birthday")
Values('Christopher','Nolan','30.07.1970');
insert into public."yonetmen"("Name","Surname","Birthday")
Values('Vince','Gilligan','10.02.1967');
insert into public."yonetmen"("Name","Surname","Birthday")
Values('Alan','Taylor','13.01.1959');
insert into public."yonetmen"("Name","Surname","Birthday")
Values('Mark','Gatiss','17.10.1966');
insert into public."yonetmen"("Name","Surname","Birthday")
values('David','Leitch','16.11.1975');
insert into public."yonetmen"("Name","Surname","Birthday")
values('Wes','Craven','02.08.1939');
insert into public."yonetmen"("Name","Surname","Birthday")
values('Mike','Flanagan','20.05.1978');
insert into public."yonetmen"("Name","Surname","Birthday")
values('James','Cameron','16.08.1954');
insert into public."yonetmen"("Name","Surname","Birthday")
values('Kim','Ji-yeon','22.10.1942');
insert into public."yonetmen"("Name","Surname","Birthday")
values('Robert','Eggers','07.07.1983');
insert into public."yonetmen"("Name","Surname","Birthday")
values('George','Kay','18.06.1979');
insert into public."yonetmen"("Name","Surname","Birthday")
values('Charlotte','Brandstrom','30.05.1959');
insert into public."yonetmen"("Name","Surname","Birthday")
values('Adam','Nee','19.07.1981');
insert into public."yonetmen"("Name","Surname","Birthday")
values('Michael','Hirst','21.09.1952');
insert into public."yonetmen"("Name","Surname","Birthday")
values('Peter','Webber','25.10.1968');
insert into public."yonetmen"("Name","Surname","Birthday")
values('Joachim','Ronning','30.05.1972');
insert into public."yonetmen"("Name","Surname","Birthday")
values('Rajkumar','Hirani','20.11.1962');
insert into public."yonetmen"("Name","Surname","Birthday")
values('Onur','Ünlü','25.06.1973');
insert into public."yonetmen"("Name","Surname","Birthday")
values('Steven','DeKnight','08.04.1964');
insert into public."yonetmen"("Name","Surname","Birthday")
values('Wolfgang','Petersen','14.03.1941');
insert into public."yonetmen"("Name","Surname","Birthday")
values('Quentin Jerome','Tarantino','27.03.1963');

select * from public."yonetmen"

/* ------------------------- */

insert into public."film"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
Values('Hobbit:Beklenmedik Yolculuk',9.3,169,'14.12.2012',1,6,2);
insert into public."film"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
Values('Hobbit:Hobbit: Smaug un Çorak Toprakları',8,161,'13.12.2013',1,6,2);
insert into public."film"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
Values('The Godfather',9.2,175,'15.03.1972',2,9,1);
insert into public."film"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
Values('The Shawshank Redemption',9.2,142,'23.09.1959',3,9,1);
insert into public."film"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
Values('Inception',8.7,148,'08.07.2010',4,4,2);
insert into public."film"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('Bullet Train',7.4,126,'05.08.2022',8,1,1);
insert into public."film"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('Scream',7.4,111,'20.12.1996',9,2,1);
insert into public."film"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('Titanic',7.9,195,'01.11.1997',11,3,2);
insert into public."film"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('The Witch',6.9,92,'18.10.2015',13,5,1);
insert into public."film"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('The Lost City',6.8,112,'25.03.2022',16,7,2);
insert into public."film"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('Girl with a Pearl Earring',6.9,100,'31.08.2003',17,8,2);
insert into public."film"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('3 Idiots',8.4,171,'25.12.2009',19,10,1);
insert into public."film"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('Troy',7.3,163,'14.05.2004',22,11,1);
insert into public."film"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('Pulp Fiction',8.9,154,'14.10.1994',23,12,1);

select * from public."film"

/* ------------------------- */

insert into public."dizi"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
Values('Breaking Bad',9.4,49,'20.01.2008',5,12,1);
insert into public."dizi"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
Values('Game of Thrones',9.1,57,'17.04.2011',6,1,2);
insert into public."dizi"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
Values('Sherlock',9,88,'25.07.2010',7,4,2);
insert into public."dizi"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('The Haunting of Hill Haouse',8.2,57,'12.10.2018',10,2,2);
insert into public."dizi"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('She Would Never Know',8.5,65,'18.01.2021',12,3,1);
insert into public."dizi"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('Criminal:UK',7.9,44,'20.09.2019',14,5,1);
insert into public."dizi"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('The Witcher',9.3,57,'20.12.2019',15,6,2);
insert into public."dizi"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('Lupin',7.5,45,'08.01.2021',14,9,1);
insert into public."dizi"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('Vikings',8.5,44,'03.03.2013',16,7,2);
insert into public."dizi"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('Marco Polo',7.3,51,'12.12.2004',18,8,1);
insert into public."dizi"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('Leyla ile Mecnun',9.1,80,'09.02.2011',20,10,1);
insert into public."dizi"("Name","IMDB","Time","VisionDate","YonetmenId","KategoriId","ReklamId")
values('Spartacus',8.5,55,'22.01.2010',21,11,2);

select * from public."dizi"
