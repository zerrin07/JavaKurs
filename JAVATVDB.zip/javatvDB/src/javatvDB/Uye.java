package javatvDB;
import java.util.Scanner;

public class Uye {
	public int Id;
	public String Name;
	public String Surname;
	public String Eposta;
	public String Sifre;
	/*bire bir ilişki için*/
	
	public int payId;
	public int uyetipiId;
	
	public void uyeKaydi(String name, String surname, String eposta, String sifre) {
		this.Name = name;
		this.Surname = surname;
		this.Eposta = eposta;
		this.Sifre = sifre;
		
	}
	public void kayit() {
		String stmt = "Insert into public.\"uye\"(\"Name\",\"Surname\",\"Eposta\",\"Sifre\",\"PaymentId\",\"UyetipiId\")"
				+ "Values(\'"+this.Name+"\',\'"+this.Surname+"\',\'"+this.Eposta+"\',\'"+this.Sifre+"',"+this.payId+","+this.uyetipiId+")";
		this.Id = DBOperation.Save(stmt);
		
	}
	public void uyeBilgileri() {
		Scanner input = new Scanner(System.in);
		
		System.out.print("Adınız :");
		String name = input.next();
		System.out.print("Soyadınız  :");
		String surname = input.next();
		System.out.print("Eposta");
		String eposta = input.next();
		System.out.print("Sifre");
		String sifre = input.next();
		
		uyeKaydi(name,surname,eposta,sifre);
		
	}
}
