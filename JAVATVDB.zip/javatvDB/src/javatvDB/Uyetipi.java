package javatvDB;

public class Uyetipi {
	public int Id;
	public int UyeType;
	
	public Uye uye = new Uye();
	
	public void kayit() {
		String stmt = "insert into public.\"uyetipi\" (\"Uyetype\") Values(\'" + this.UyeType +"\')";
		this.Id = DBOperation.Save(stmt);
		 uye.Id= this.Id;
		
	}
	public void uyeTipiListeleme() {
		System.out.println("Secmek istediginiz uyelik tipini giriniz: \n");
        System.out.print("(1) Basic --- 20TL \n"
                		+ "(2) Premium --- 80TL \n");
	}
}
