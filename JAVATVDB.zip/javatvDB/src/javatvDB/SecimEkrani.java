package javatvDB;
import java.util.Scanner;
public class SecimEkrani {
	
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
        Yonetmen yon = new Yonetmen();
        Kategori kat = new Kategori();
        Dizi diz = new Dizi();
        Film flm = new Film();
        Uye uye = new Uye();
        Reklam rek = new Reklam();
        GorselYazdirma gy = new GorselYazdirma();
        Payment payment = new Payment();
        Uyetipi uyetipi = new Uyetipi();
        
        //hosgeldiniz
        gy.Hosgelsiniz();
        System.out.println("Uye olmak için bilgilerinizi giriniz: \n");
        
        uye.uyeBilgileri();
        /*-----------------------------*/
        uyetipi.uyeTipiListeleme();
        uye.uyetipiId = input.nextInt();
        if(uye.uyetipiId==1||uye.uyetipiId==2) {
        	if(uye.uyetipiId==2) {
            	diz.updateMyList(2,1);
            	flm.updateMyList(2,1);
            }
            else if(uye.uyetipiId==1) {
            	diz.updateMyList(1,2);
            	flm.updateMyList(1,2);
            }
            uyetipi.kayit();
            /*-----------------------------*/

            payment.paymentTipiListeleme();
            uye.payId = input.nextInt();
            if(uye.payId==1||uye.payId==2||uye.payId==3||uye.payId==4||uye.payId==5||uye.payId==6) {
            	payment.kayit();
            	uye.kayit();
                int i=1;
            	while(i>0) {
            		System.out.println("Lutfen secim yapiniz");
                    System.out.print("(1) Yonetmen \n"
                            + "(2) Kategori \n"
                            + "(3) Dizi \n"
                            + "(4) Film \n");
                    int secim = input.nextInt();
            		if(secim == 1) {
            			
            			 yon.listele();
            			 System.out.println("Tercih ettiğiniz yonetmen Id giriniz...");
            			 int yonetmenValue = input.nextInt();
            			 if(yon.kayitVarmi(yonetmenValue)!=1){
            				 diz.listele(yonetmenValue,"YonetmenId");
                			 flm.listele(yonetmenValue,"YonetmenId");
                	         //iyi seyirler
                			  gy.iyiSeyirler();
            			 }
            			 else {
            				 System.out.println("gecersiz secim yaptiniz !");
            				 gy.hatalıSecim(1);
            			 }
            			 
            		}
            		else if(secim == 2) {
            			kat.listele();
            			System.out.println("Tercih ettiğiniz kategori Id giriniz...");
            			int kategoriValue = input.nextInt();
            			if(kat.kayitVarmi(kategoriValue)!=1){
	            			diz.listele(kategoriValue,"KategoriId");
	            			flm.listele(kategoriValue,"KategoriId");
	            	        //iyi seyirler
	            			gy.iyiSeyirler();
            			}
            			else {
            				System.out.println("gecersiz secim yaptiniz !");
            				gy.hatalıSecim(2);
            			}
            		}
            		else if(secim == 3) {
            			diz.listele();
            			System.out.println("Izlemek istediğiniz Id giriniz...");
            	        int ksecim=input.nextInt();
            	        if(diz.kayitVarmi(ksecim)!=1){
	            	        //iyi seyirler
            	        	gy.iyiSeyirler();
            	        }
            	        else {
            	        	 System.out.println("gecersiz secim yaptiniz !");
            	        	 gy.hatalıSecim(3);
            	        }
            			
            		}
            		else if(secim == 4) {
            			flm.listele();
            			System.out.println("Izlemek istediğiniz Id giriniz...");
            	        int ksecim=input.nextInt();
            	        if(flm.kayitVarmi(ksecim)!=1){
	            	        //iyi seyirler
            	        	gy.iyiSeyirler();
            	        }
            	        else {
            	        	 System.out.println("gecersiz secim yaptiniz !");
            	        	 gy.hatalıSecim(1);
            	        }
            		}
            		else {
            			System.out.println("Geçerli kategori giriniz");
            			//gecersiz secim**1
            			gy.hatalıSecim(1);
            		}

            	}           
            }
            else {
            	System.out.println("Odeme işleminiz gerçekleştirilemedi");
            	//gecersiz secim **2
            	gy.hatalıSecim(2);
            	
            }
            
        }
        else {
        	System.out.println("Gecersiz Uyelik tipi girdiniz");
        	//gecersiz secim 3
        	gy.hatalıSecim(3);
        }
  
	}

}
