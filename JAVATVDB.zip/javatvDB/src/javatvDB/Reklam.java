package javatvDB;

public class Reklam {
	public int Id;
	public String ReklamType;
	public Film film = new Film();
	public Dizi dizi = new Dizi();
	
	public void kayit() {
		String stmt = "insert into public.\"Reklam\" (\"ReklamType\") Values(\'" + this.ReklamType +"\')";
		this.Id = DBOperation.Save(stmt);
		film.ReklamId = this.Id;
		film.kayit();
		dizi.ReklamId = this.Id;
		dizi.kayit();
		
	}
}
