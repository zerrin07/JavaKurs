package javatvDB;

public class Payment {
	public int Id;
	public String PayType;
	
	public Uye uye = new Uye();
	
	public void kayit() {
		String stmt = "insert into public.\"payment\" (\"PaymentType\") Values(\'" + this.PayType +"\')";
		this.Id = DBOperation.Save(stmt);
		uye.Id= this.Id;	
	}
	public void paymentTipiListeleme() {
		System.out.println("Odeme yontemini seciniz: \n");
        System.out.print("(1) Kredi Karti \n"
                + "(2) Banka Karti \n"
                + "(3) Paypal \n"
                + "(4) Kripto \n"
                + "(5) Kupon \n"
                + "(6) Papara \n");
	}
}
