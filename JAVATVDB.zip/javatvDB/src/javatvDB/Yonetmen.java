package javatvDB;
import java.util.ArrayList;
import java.util.Scanner;
import java.sql.*;
public class Yonetmen {
	public int Id;
	public String Name;
	public String Surname;
	public String Birthday;
	
	public Film film = new Film();
	public Dizi dizi = new Dizi();
	
	public ArrayList<Yonetmen> yonetmenArray=new ArrayList<Yonetmen>();
	
	public void kayit() {
		String stmt = "insert into public.\"yonetmen\"(\"Name\",\"Surname\",\"Birthday\") "
				+ "values(\'"+this.Name+"\',\'"+this.Surname+"\',\'"+this.Birthday+"\')";
		this.Id=DBOperation.Save(stmt);
		film.YonetmenId=this.Id;
		film.kayit(); 
		dizi.YonetmenId=this.Id;
		dizi.kayit(); 
	}
	public int kayitVarmi(int s) {
		String stmt = "select * from public.\"yonetmen\" where \"Id\"="+s ;
		return DBOperation.Save(stmt);
	}
	public void listele()  {
		String stmt = "Select \"Id\",\"Name\",\"Surname\" from public.\"yonetmen\"";
		ResultSet rs = DBOperation.returnRS(stmt);
	
		
		try {
			while(rs.next()) {
			Yonetmen yont= new Yonetmen();
			yont.Id=rs.getInt("Id");
			yont.Name = rs.getString("Name");
			yont.Surname = rs.getString("Surname");
			yonetmenArray.add(yont);
			}
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for(Yonetmen c : yonetmenArray)
		{
			System.out.println(c.Id+"\t"+c.Name + "\t" + c.Surname);
			
		}
	}
	
}
